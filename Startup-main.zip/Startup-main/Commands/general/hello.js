module.exports = {
    name: "hello",
    description: "Say hello to the bot",
  async run(client, message, args){
        message.reply("Hello!");
    }
}
